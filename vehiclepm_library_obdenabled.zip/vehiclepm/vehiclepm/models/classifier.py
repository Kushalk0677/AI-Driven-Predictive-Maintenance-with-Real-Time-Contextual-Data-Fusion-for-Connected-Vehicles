"""
VehiclePMClassifier — unified interface for vehicle predictive maintenance.

Wraps LightGBM (default), XGBoost, Random Forest, and Logistic Regression
with built-in SMOTE, cross-validation, SHAP, and probability calibration.
"""

import numpy as np
import pandas as pd
from typing import Optional, List, Dict, Any

from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.metrics import f1_score, roc_auc_score
from sklearn.calibration import CalibratedClassifierCV
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline

try:
    from lightgbm import LGBMClassifier
    _LGBM_AVAILABLE = True
except ImportError:
    _LGBM_AVAILABLE = False

try:
    from xgboost import XGBClassifier
    _XGB_AVAILABLE = True
except ImportError:
    _XGB_AVAILABLE = False


_MODEL_REGISTRY = {
    "lightgbm": lambda: LGBMClassifier(
        n_estimators=200, learning_rate=0.05, num_leaves=31,
        class_weight="balanced", random_state=42, verbose=-1
    ) if _LGBM_AVAILABLE else None,
    "xgboost": lambda: XGBClassifier(
        n_estimators=200, learning_rate=0.05, max_depth=5,
        use_label_encoder=False, eval_metric="logloss",
        random_state=42
    ) if _XGB_AVAILABLE else None,
    "random_forest": lambda: RandomForestClassifier(
        n_estimators=200, max_depth=10,
        class_weight="balanced", random_state=42
    ),
    "logistic_regression": lambda: LogisticRegression(
        C=1.0, class_weight="balanced",
        max_iter=1000, random_state=42
    ),
}


class VehiclePMClassifier:
    """
    Predictive maintenance classifier with built-in SMOTE and cross-validation.

    Parameters
    ----------
    model_type : str
        One of 'lightgbm' (default), 'xgboost', 'random_forest',
        'logistic_regression'.
    n_splits : int
        Number of stratified CV folds. Default 5.
    calibrate : bool
        If True, wrap the final model with Platt scaling calibration.
        Default False.
    smote_sampling_strategy : float or str
        SMOTE sampling strategy passed to imblearn. Default 'auto'.
    random_state : int
        Random seed. Default 42.

    Example
    -------
    >>> from vehiclepm import VehiclePMClassifier, generate_synthetic_dataset
    >>> from vehiclepm.features import build_feature_matrix
    >>>
    >>> df = generate_synthetic_dataset(n_samples=2000)
    >>> X = build_feature_matrix(df.drop(columns=["risk_score", "maintenance_needed"]))
    >>> y = df["maintenance_needed"]
    >>>
    >>> clf = VehiclePMClassifier(model_type="lightgbm")
    >>> results = clf.cross_validate(X, y)
    >>> print(results)
    """

    def __init__(
        self,
        model_type: str = "lightgbm",
        n_splits: int = 5,
        calibrate: bool = False,
        smote_sampling_strategy: Any = "auto",
        random_state: int = 42,
    ):
        if model_type not in _MODEL_REGISTRY:
            raise ValueError(
                f"Unknown model_type '{model_type}'. "
                f"Choose from: {list(_MODEL_REGISTRY.keys())}"
            )
        self.model_type = model_type
        self.n_splits = n_splits
        self.calibrate = calibrate
        self.smote_sampling_strategy = smote_sampling_strategy
        self.random_state = random_state
        self._model = None
        self._feature_names: Optional[List[str]] = None

    def _build_pipeline(self):
        base = _MODEL_REGISTRY[self.model_type]()
        if base is None:
            raise ImportError(
                f"'{self.model_type}' is not installed. "
                f"Run: pip install {self.model_type}"
            )
        smote = SMOTE(
            sampling_strategy=self.smote_sampling_strategy,
            random_state=self.random_state,
        )
        if self.calibrate:
            base = CalibratedClassifierCV(base, method="sigmoid", cv=3)
        return ImbPipeline([("smote", smote), ("classifier", base)])

    def cross_validate(
        self, X: pd.DataFrame, y: pd.Series
    ) -> Dict[str, Any]:
        """
        Run stratified k-fold cross-validation with SMOTE inside each fold.

        Parameters
        ----------
        X : pd.DataFrame
            Feature matrix.
        y : pd.Series
            Binary target (0 = no maintenance, 1 = maintenance needed).

        Returns
        -------
        dict with keys:
            'f1_mean', 'f1_std', 'f1_scores',
            'auc_mean', 'auc_std', 'auc_scores'
        """
        self._feature_names = list(X.columns)
        cv = StratifiedKFold(
            n_splits=self.n_splits, shuffle=True, random_state=self.random_state
        )

        f1_scores, auc_scores = [], []

        for train_idx, val_idx in cv.split(X, y):
            X_train, X_val = X.iloc[train_idx], X.iloc[val_idx]
            y_train, y_val = y.iloc[train_idx], y.iloc[val_idx]

            pipe = self._build_pipeline()
            pipe.fit(X_train, y_train)

            y_pred = pipe.predict(X_val)
            y_prob = pipe.predict_proba(X_val)[:, 1]

            f1_scores.append(f1_score(y_val, y_pred, average="macro"))
            auc_scores.append(roc_auc_score(y_val, y_prob))

        # Store last fold model for later use (SHAP, etc.)
        self._model = pipe

        return {
            "f1_mean":   float(np.mean(f1_scores)),
            "f1_std":    float(np.std(f1_scores)),
            "f1_scores": f1_scores,
            "auc_mean":  float(np.mean(auc_scores)),
            "auc_std":   float(np.std(auc_scores)),
            "auc_scores": auc_scores,
        }

    def fit(self, X: pd.DataFrame, y: pd.Series) -> "VehiclePMClassifier":
        """
        Fit on the full training set.

        Parameters
        ----------
        X : pd.DataFrame
        y : pd.Series

        Returns
        -------
        self
        """
        self._feature_names = list(X.columns)
        self._model = self._build_pipeline()
        self._model.fit(X, y)
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """Predict binary maintenance labels."""
        self._check_fitted()
        return self._model.predict(X)

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """Predict maintenance probability scores."""
        self._check_fitted()
        return self._model.predict_proba(X)

    def get_base_model(self):
        """Return the fitted base estimator (for SHAP, etc.)."""
        self._check_fitted()
        # Extract from pipeline
        return self._model.named_steps["classifier"]

    def _check_fitted(self):
        if self._model is None:
            raise RuntimeError("Model not fitted. Call fit() or cross_validate() first.")

    def __repr__(self):
        return (
            f"VehiclePMClassifier(model_type='{self.model_type}', "
            f"n_splits={self.n_splits}, calibrate={self.calibrate})"
        )
