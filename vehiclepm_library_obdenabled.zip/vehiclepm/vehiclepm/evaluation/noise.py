"""
Noise sensitivity analysis.

Replicates Experiment 4 from the paper: characterises how model performance
degrades as Gaussian sensor noise is increased from sigma=0 to sigma=3.
"""

import numpy as np
import pandas as pd
from typing import List, Optional, Dict, Any

from sklearn.metrics import f1_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline


def noise_sensitivity_analysis(
    X: pd.DataFrame,
    y: pd.Series,
    classifier,
    sigma_levels: Optional[List[float]] = None,
    n_seeds: int = 5,
    n_splits: int = 5,
) -> pd.DataFrame:
    """
    Evaluate model robustness by injecting increasing Gaussian noise into features.

    For each noise level sigma, Gaussian noise N(0, sigma) is added to all
    numeric feature columns. The model is retrained and evaluated n_seeds times
    per sigma level to produce stable mean/std estimates.

    Parameters
    ----------
    X : pd.DataFrame
        Feature matrix (numeric columns only will be noised).
    y : pd.Series
        Binary target.
    classifier : VehiclePMClassifier or sklearn estimator
        Unfitted classifier with a fit/predict/predict_proba interface.
    sigma_levels : list of float, optional
        Noise sigma values to evaluate.
        Default: [0.0, 0.25, 0.5, 1.0, 1.5, 2.0, 3.0]
    n_seeds : int
        Number of random seeds per sigma level. Default 5.
    n_splits : int
        CV folds per seed. Default 5.

    Returns
    -------
    pd.DataFrame with columns:
        sigma, f1_mean, f1_std, auc_mean, auc_std

    Example
    -------
    >>> from vehiclepm import VehiclePMClassifier, generate_synthetic_dataset, noise_sensitivity_analysis
    >>> from vehiclepm.features import build_feature_matrix
    >>> df = generate_synthetic_dataset()
    >>> X = build_feature_matrix(df.drop(columns=["risk_score","maintenance_needed"]))
    >>> y = df["maintenance_needed"]
    >>> clf = VehiclePMClassifier()
    >>> results = noise_sensitivity_analysis(X, y, clf)
    >>> print(results)
    """
    if sigma_levels is None:
        sigma_levels = [0.0, 0.25, 0.5, 1.0, 1.5, 2.0, 3.0]

    numeric_cols = X.select_dtypes(include=[np.number]).columns.tolist()
    records = []

    for sigma in sigma_levels:
        seed_f1, seed_auc = [], []

        for seed in range(n_seeds):
            rng = np.random.default_rng(seed)

            # Inject noise
            X_noised = X.copy()
            if sigma > 0:
                noise = rng.normal(0, sigma, size=(len(X), len(numeric_cols)))
                X_noised[numeric_cols] = X_noised[numeric_cols].values + noise

            # Cross-validate
            cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
            fold_f1, fold_auc = [], []

            for train_idx, val_idx in cv.split(X_noised, y):
                X_tr, X_val = X_noised.iloc[train_idx], X_noised.iloc[val_idx]
                y_tr, y_val = y.iloc[train_idx], y.iloc[val_idx]

                pipe = classifier._build_pipeline()
                pipe.fit(X_tr, y_tr)

                y_pred = pipe.predict(X_val)
                y_prob = pipe.predict_proba(X_val)[:, 1]

                fold_f1.append(f1_score(y_val, y_pred, average="macro"))
                fold_auc.append(roc_auc_score(y_val, y_prob))

            seed_f1.append(np.mean(fold_f1))
            seed_auc.append(np.mean(fold_auc))

        records.append({
            "sigma":    sigma,
            "f1_mean":  float(np.mean(seed_f1)),
            "f1_std":   float(np.std(seed_f1)),
            "auc_mean": float(np.mean(seed_auc)),
            "auc_std":  float(np.std(seed_auc)),
        })

    return pd.DataFrame(records)
