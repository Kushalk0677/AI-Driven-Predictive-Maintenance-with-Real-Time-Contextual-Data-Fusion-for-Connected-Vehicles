# vehiclepm 🚗

**Predictive Maintenance for Connected Vehicles with V2X Contextual Data Fusion**

[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

A Python library implementing the contextual data fusion framework for V2X-augmented vehicle predictive maintenance, as described in:

> Khemani, K. & Qureshi, A.N. (2026). *AI-Driven Predictive Maintenance with Real-Time Contextual Data Fusion for Connected Vehicles: A Multi-Dataset Evaluation.* arXiv:submit/7337442

---

## Installation

```bash
pip install vehiclepm
```

---

## Quick Start

```python
from vehiclepm import VehiclePMClassifier, generate_synthetic_dataset
from vehiclepm.features import build_feature_matrix

# 1. Generate synthetic dataset
df = generate_synthetic_dataset(n_samples=2000, noise_sigma=1.0)

# 2. Build feature matrix (all 4 groups)
X = build_feature_matrix(df.drop(columns=["risk_score", "maintenance_needed"]))
y = df["maintenance_needed"]

# 3. Train and evaluate with 5-fold CV + SMOTE
clf = VehiclePMClassifier(model_type="lightgbm")
results = clf.cross_validate(X, y)

print(f"F1: {results['f1_mean']:.3f} ± {results['f1_std']:.3f}")
print(f"AUC: {results['auc_mean']:.3f} ± {results['auc_std']:.3f}")
```

---

## Features

### Four Feature Groups (as per paper)

| Group | Features | Description |
|-------|----------|-------------|
| A — Mechanical | 9 | Engine temp, brake thickness, battery health, oil degradation, etc. |
| B — Driver | 4 | Hard braking frequency, acceleration variance, driving style |
| C — Environmental/V2X | 6 | Road roughness (IRI), weather, traffic density, ambient temp |
| D — Interactions | 4 | Engine thermal load, brake stress index, traffic-road impact |

```python
from vehiclepm.features import build_feature_matrix

# All groups
X = build_feature_matrix(df)

# Specific groups (ablation)
X = build_feature_matrix(df, include_groups=["mechanical", "environmental"])
```

### Ablation Study

```python
from vehiclepm.evaluation.ablation import run_ablation_study

results = run_ablation_study(df, target_col="maintenance_needed", classifier=clf)
print(results)
```

Output:
```
                  configuration  n_features  f1_mean  f1_std  auc_mean  f1_drop
    All Features (Full Model)          24    0.855   0.015     0.944      0.0
    Without Environmental (V2X)        18    0.829   0.019     0.930     -0.026
    Internal Only (No Context)          9    0.807   0.018     0.904     -0.049
    ...
```

### Noise Sensitivity Analysis

```python
from vehiclepm import noise_sensitivity_analysis

results = noise_sensitivity_analysis(X, y, clf)
print(results)
#    sigma  f1_mean  f1_std  auc_mean  auc_std
#      0.0    0.887   0.015     0.969    0.008
#      0.5    0.879   0.009     0.964    0.006
#      1.0    0.848   0.012     0.936    0.010
#      2.0    0.740   0.028     0.812    0.018
```

### SHAP Feature Importance

```python
from vehiclepm.interpretability.shap_analysis import compute_shap_importance

clf.fit(X, y)
importance_df = compute_shap_importance(clf.get_base_model(), X)
# Returns top-15 features + generates bar chart and beeswarm plot
```

### Probability Calibration

```python
clf_calibrated = VehiclePMClassifier(model_type="lightgbm", calibrate=True)
clf_calibrated.fit(X_train, y_train)
probs = clf_calibrated.predict_proba(X_test)
```

---

## Supported Models

| model_type | Requires |
|------------|----------|
| `lightgbm` (default) | `pip install lightgbm` |
| `xgboost` | `pip install xgboost` |
| `random_forest` | built-in |
| `logistic_regression` | built-in |

---

## Project Structure

```
vehiclepm/
├── features/
│   └── engineering.py    # Groups A–D feature computation
├── models/
│   └── classifier.py     # VehiclePMClassifier
├── evaluation/
│   ├── ablation.py       # Feature group ablation study
│   └── noise.py          # Noise sensitivity analysis
├── interpretability/
│   └── shap_analysis.py  # SHAP feature importance
├── calibration/          # Probability calibration utilities
└── data/
    └── synthetic.py      # Physics-informed dataset generator
```

---

## Citation

```bibtex
@article{khemani2026vehiclepm,
  title   = {AI-Driven Predictive Maintenance with Real-Time Contextual Data
             Fusion for Connected Vehicles: A Multi-Dataset Evaluation},
  author  = {Khemani, Kushal and Qureshi, Anjum Nazir},
  journal = {arXiv preprint arXiv:submit/7337442},
  year    = {2026}
}
```

---

## License

MIT License — see [LICENSE](LICENSE) for details.

---

## 🔌 Live OBD-II Prediction

Connect any **ELM327 USB or Bluetooth OBD-II dongle** to your car and get real-time maintenance predictions.

### Install OBD dependency
```bash
pip install vehiclepm obd
```

### Run live predictions

```python
from vehiclepm import VehiclePMClassifier, generate_synthetic_dataset, LivePredictor, VehicleContext
from vehiclepm.features import build_feature_matrix

# 1. Train the model (or load a pre-trained one)
df = generate_synthetic_dataset(n_samples=2000)
X = build_feature_matrix(df.drop(columns=["risk_score", "maintenance_needed"]))
y = df["maintenance_needed"]
clf = VehiclePMClassifier()
clf.fit(X, y)

# 2. Set your vehicle details
ctx = VehicleContext(
    mileage=82000,          # km on odometer
    vehicle_age=6,          # years
    brake_thickness=4.0,    # mm — check your last service report
    tire_tread=3.5,         # mm
    oil_degradation=0.6,    # 0=new oil, 1=degraded
    weather_condition="Rain",
    road_roughness=5.0,     # IRI scale
    road_type="Urban",
)

# 3. Plug in dongle and run — predictions every 5 seconds
predictor = LivePredictor(model=clf, context=ctx)
predictor.run()
```

### Output
```
vehiclepm — Live Maintenance Predictor
Connecting to OBD-II dongle...
Connected. Predicting every 5.0s. Press Ctrl+C to stop.

[OK]       Maintenance probability: 18% | Engine: 89.2°C | Battery: 87% | DTCs: 0 | Style: Smooth
[OK]       Maintenance probability: 22% | Engine: 91.4°C | Battery: 86% | DTCs: 0 | Style: Smooth
[WATCH]    Maintenance probability: 41% | Engine: 103.1°C | Battery: 82% | DTCs: 0 | Style: Aggressive
[WARNING]  Maintenance probability: 61% | Engine: 108.7°C | Battery: 79% | DTCs: 1 | Style: Aggressive
[CRITICAL] Maintenance probability: 84% | Engine: 115.2°C | Battery: 71% | DTCs: 2 | Style: Aggressive
```

### Custom alert (e.g. push notification, SMS)
```python
def my_alert(alert):
    if alert.severity in ("WARNING", "CRITICAL"):
        print(f"🚨 Book a service! Risk: {alert.probability:.0%}")
        # send_sms(), send_push_notification(), etc.

predictor = LivePredictor(model=clf, context=ctx, on_alert=my_alert)
predictor.run()
```

### Supported OBD-II Sensors
| Sensor | OBD PID | Used for |
|--------|---------|----------|
| Coolant Temperature | COOLANT_TEMP | Engine thermal load |
| RPM | RPM | Engine stress |
| Throttle Position | THROTTLE_POS | Driver behaviour |
| Fuel Level | FUEL_LEVEL | Mechanical state |
| Engine Load | ENGINE_LOAD | Thermal stress |
| Speed | SPEED | Driver behaviour / braking |
| Battery Voltage | CONTROL_MODULE_VOLTAGE | Battery health |
| Active DTCs | GET_DTC | Sensor fault flag |

> **Note:** Not all vehicles support all PIDs. Missing sensors fall back to safe defaults automatically.
