"""
vehiclepm — No-OBD Trial Run
=============================
Simulates a live OBD feed using mock sensor readings so you can
test the full pipeline without a dongle.

Run:
    python trial_run.py
"""

import time
import random
import pandas as pd
import numpy as np
from dataclasses import dataclass
from typing import Optional

# ── 1. Install check ──────────────────────────────────────────────────────────
print("=" * 60)
print("  vehiclepm — Trial Run (No OBD Dongle)")
print("=" * 60)

try:
    from vehiclepm import VehiclePMClassifier, generate_synthetic_dataset
    from vehiclepm.features import build_feature_matrix
    from vehiclepm.obd.adapter import OBDFeatureAdapter, VehicleContext
    from vehiclepm.obd.live import MaintenanceAlert, _get_severity
    from vehiclepm.obd.reader import OBDReading
    print("\n✅ vehiclepm imported successfully\n")
except ImportError as e:
    print(f"\n❌ Import failed: {e}")
    print("Run: pip install -e . from the vehiclepm folder\n")
    exit(1)

# ── 2. Train model on synthetic data ──────────────────────────────────────────
print("Step 1: Training model on synthetic data...")
df = generate_synthetic_dataset(n_samples=2000, random_state=42)
X = build_feature_matrix(df.drop(columns=["risk_score", "maintenance_needed"]))
y = df["maintenance_needed"]

clf = VehiclePMClassifier(model_type="lightgbm")
results = clf.cross_validate(X, y)

print(f"  ✅ Model trained")
print(f"  F1:  {results['f1_mean']:.3f} ± {results['f1_std']:.3f}")
print(f"  AUC: {results['auc_mean']:.3f} ± {results['auc_std']:.3f}")

# Fit on full dataset for live use
clf.fit(X, y)

# ── 3. Set up vehicle context (your Safari Storme) ────────────────────────────
print("\nStep 2: Setting up vehicle context (Tata Safari Storme 2014)...")

ctx = VehicleContext(
    mileage=120000,
    vehicle_age=12,
    brake_thickness=5.0,
    tire_tread=4.0,
    oil_degradation=0.4,
    ambient_temp=28.0,
    road_roughness=4.5,
    traffic_density=35.0,
    road_type="Urban",
    weather_condition="Clear",
    monthly_precipitation=60.0,
)
print("  ✅ Vehicle context set")

# ── 4. Mock OBD reading generator ─────────────────────────────────────────────

def make_mock_reading(scenario: str = "normal") -> OBDReading:
    """
    Generate a realistic mock OBD reading for a Safari Storme.

    Scenarios:
        'normal'    — healthy car, normal driving
        'warning'   — elevated engine temp, some hard braking
        'critical'  — high temp, low battery, active DTCs
    """
    reading = OBDReading(timestamp=time.time())

    if scenario == "normal":
        reading.engine_temp      = random.uniform(85, 95)
        reading.rpm              = random.uniform(800, 2500)
        reading.throttle_pos     = random.uniform(10, 40)
        reading.fuel_level       = random.uniform(0.5, 0.8)
        reading.engine_load      = random.uniform(20, 50)
        reading.speed            = random.uniform(30, 60)
        reading.battery_voltage  = random.uniform(12.4, 12.7)
        reading.dtc_count        = 0

    elif scenario == "warning":
        reading.engine_temp      = random.uniform(100, 108)
        reading.rpm              = random.uniform(2000, 3500)
        reading.throttle_pos     = random.uniform(40, 70)
        reading.fuel_level       = random.uniform(0.2, 0.4)
        reading.engine_load      = random.uniform(60, 80)
        reading.speed            = random.uniform(50, 90)
        reading.battery_voltage  = random.uniform(12.0, 12.3)
        reading.dtc_count        = 0

    elif scenario == "critical":
        reading.engine_temp      = random.uniform(109, 118)
        reading.rpm              = random.uniform(3000, 4500)
        reading.throttle_pos     = random.uniform(70, 95)
        reading.fuel_level       = random.uniform(0.05, 0.15)
        reading.engine_load      = random.uniform(80, 100)
        reading.speed            = random.uniform(60, 110)
        reading.battery_voltage  = random.uniform(11.5, 11.9)
        reading.dtc_count        = random.randint(1, 3)

    # Derive battery health from voltage
    v = reading.battery_voltage
    reading.battery_health = min(1.0, max(0.0, (v - 11.5) / (12.8 - 11.5)))
    reading.sensor_fault = 1 if reading.dtc_count > 0 else 0

    return reading


# ── 5. Run mock live predictions ──────────────────────────────────────────────
print("\nStep 3: Running mock live predictions...")
print("-" * 60)
print(f"{'#':<4} {'Scenario':<10} {'Prob':>6}  {'Severity':<10} {'Engine':>8}  {'Battery':>8}  {'DTCs':>5}")
print("-" * 60)

COLOURS = {
    "OK":       "\033[92m",
    "WATCH":    "\033[93m",
    "WARNING":  "\033[33m",
    "CRITICAL": "\033[91m",
}
RESET = "\033[0m"

# Simulate a drive: starts normal, degrades to warning, then critical
scenarios = (
    ["normal"] * 5 +
    ["warning"] * 5 +
    ["critical"] * 5
)

adapter = OBDFeatureAdapter(context=ctx)

for i, scenario in enumerate(scenarios, 1):
    reading = make_mock_reading(scenario)

    # Build features
    raw_df = adapter.to_features(reading)
    X_live = build_feature_matrix(raw_df)

    # Predict
    prob = float(clf.predict_proba(X_live)[0, 1])
    severity = _get_severity(prob)
    colour = COLOURS.get(severity, "")

    print(
        f"{colour}"
        f"{i:<4} {scenario:<10} {prob:>5.1%}  {severity:<10} "
        f"{reading.engine_temp:>7.1f}°C  "
        f"{reading.battery_health:>7.0%}    "
        f"{reading.dtc_count:>4}"
        f"{RESET}"
    )

    time.sleep(0.3)  # small delay to simulate real-time

print("-" * 60)
print("\n✅ Trial run complete!")
print("\nWhat this means:")
print("  🟢 OK       — No maintenance needed")
print("  🟡 WATCH    — Keep an eye on it")
print("  🟠 WARNING  — Book a service soon")
print("  🔴 CRITICAL — Service needed urgently")
print("\nWhen your OBD dongle arrives, replace mock readings with:")
print("  predictor = LivePredictor(model=clf, context=ctx, port='COM6')")
print("  predictor.run()")
